
#import necessary libraries
import numpy as np
import cv2
import numpy as np
from scipy import ndimage as ndi
import skimage.segmentation
import pymeanshift as pms



import numpy as np
import cv2 as cv
img = cv.imread('temp.jpg')

cv.imwrite('res2.png',res2)
cv.waitKey(0)
        